# Surf - Chat Anywhere
#### Design document

#### Models
- Message
- Chat
- User
- Domain

#### Services
- Database_service
- Authentication
- HTML Actuator

#### Pages
- Sign-up
- Domain chat
- Page chat
- Friend chat
- Profile (self)
- Profile (other)
- Friend requests